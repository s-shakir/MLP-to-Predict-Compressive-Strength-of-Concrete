# Loading Data
Yts=np.loadtxt("TestData.csv")
Ytsdat = torch.from_numpy(Yts).type(torch.float)

# Loading the model
mod = Net()
predict = mod(Ytsdat)
mod.load_state_dict(torch.load(file))
mod.eval()


p = predict.detach().numpy()
p_df = pd.DataFrame(p)
p_df.to_csv('20I-2003_predictions.csv')
